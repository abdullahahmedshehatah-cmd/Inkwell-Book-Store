// Inkwell- main.js
// Beginner-friendly: simple functions, loops, and comments.
//
// What this file does:
//   1. Filters the books by category
//   2. Shows a details pop-up for a book
//   3. Runs the shopping cart (add, change quantity, remove, total)
//   4. Saves the cart in the browser so it survives a refresh


// ===== 1. GET ELEMENTS FROM THE PAGE =====
const filterButtons  = document.querySelectorAll(".filter-btn");
const bookCards      = document.querySelectorAll(".book-card");
const detailsButtons = document.querySelectorAll(".details-btn");
const addButtons     = document.querySelectorAll(".add-btn");

const cartButton   = document.getElementById("cart-button");
const cartCount    = document.getElementById("cart-count");
const cartPanel    = document.getElementById("cart");
const cartClose    = document.getElementById("cart-close");
const cartItems    = document.getElementById("cart-items");
const cartTotal    = document.getElementById("cart-total");
const cartMessage  = document.getElementById("cart-message");
const checkoutBtn  = document.getElementById("checkout-btn");
const clearBtn     = document.getElementById("clear-btn");
const overlay      = document.getElementById("overlay");

const modal            = document.getElementById("details-modal");
const modalClose       = document.getElementById("modal-close");
const modalImage       = document.getElementById("modal-image");
const modalCategory    = document.getElementById("modal-category");
const modalTitle       = document.getElementById("modal-title");
const modalAuthor      = document.getElementById("modal-author");
const modalDescription = document.getElementById("modal-description");
const modalPages       = document.getElementById("modal-pages");
const modalYear        = document.getElementById("modal-year");
const modalPrice       = document.getElementById("modal-price");
const modalAdd         = document.getElementById("modal-add");


// ===== 2. VARIABLES =====
// The cart is an array. Each item looks like:
// { id: "atomic-habits", title: "Atomic Habits", price: 18, image: "images/...", quantity: 2 }
let cart = [];

// The book card that is currently shown in the details pop-up
let currentCard = null;


// ===== 3. SMALL HELPER FUNCTIONS =====

// Turn 18 into "$18.00"
function formatPrice(number) {
  return "$" + number.toFixed(2);
}

// Read the information stored in a card's data-* attributes
function getBookFromCard(card) {
  return {
    id: card.dataset.id,
    title: card.dataset.title,
    price: Number(card.dataset.price),   // data-* values are text, so convert to a number
    image: card.dataset.image,
    quantity: 1
  };
}


// ===== 4. FILTER THE BOOKS =====
function filterBooks(category) {
  for (const card of bookCards) {
    if (category === "All" || card.dataset.category === category) {
      card.style.display = "";       // show (use the CSS default)
    } else {
      card.style.display = "none";   // hide
    }
  }

  // Highlight only the button that was clicked
  for (const button of filterButtons) {
    if (button.dataset.category === category) {
      button.classList.add("active");
    } else {
      button.classList.remove("active");
    }
  }
}

for (const button of filterButtons) {
  button.addEventListener("click", function () {
    filterBooks(button.dataset.category);
  });
}


// ===== 5. DETAILS POP-UP =====
function openModal(card) {
  currentCard = card;

  modalImage.src = card.dataset.image;
  modalImage.alt = "Cover of " + card.dataset.title;
  modalCategory.textContent = card.dataset.category;
  modalTitle.textContent = card.dataset.title;
  modalAuthor.textContent = "by " + card.dataset.author;
  modalDescription.textContent = card.dataset.description;
  modalPages.textContent = card.dataset.pages;
  modalYear.textContent = card.dataset.year;
  modalPrice.textContent = formatPrice(Number(card.dataset.price));

  modal.classList.add("open");
  document.body.classList.add("no-scroll");
}

function closeModal() {
  modal.classList.remove("open");
  document.body.classList.remove("no-scroll");
}

for (const button of detailsButtons) {
  button.addEventListener("click", function () {
    // button.closest(...) finds the card that contains this button
    openModal(button.closest(".book-card"));
  });
}

modalClose.addEventListener("click", closeModal);

// Clicking the dark background (outside the white box) also closes it
modal.addEventListener("click", function (event) {
  if (event.target === modal) {
    closeModal();
  }
});

modalAdd.addEventListener("click", function () {
  addToCart(getBookFromCard(currentCard));
});


// ===== 6. CART: OPEN AND CLOSE =====
function openCart() {
  cartPanel.classList.add("open");
  overlay.classList.add("open");
  document.body.classList.add("no-scroll");
}

function closeCart() {
  cartPanel.classList.remove("open");
  overlay.classList.remove("open");
  document.body.classList.remove("no-scroll");
}

cartButton.addEventListener("click", openCart);
cartClose.addEventListener("click", closeCart);
overlay.addEventListener("click", closeCart);


// ===== 7. CART: CHANGE THE DATA =====

// Find a book in the cart by id. Returns the item, or null if it is not there.
function findInCart(id) {
  for (const item of cart) {
    if (item.id === id) {
      return item;
    }
  }
  return null;
}

function addToCart(book) {
  cartMessage.textContent = "";

  const existing = findInCart(book.id);
  if (existing) {
    existing.quantity = existing.quantity + 1;   // already in the cart: add one more
  } else {
    cart.push(book);                             // new book: add it to the array
  }
  updateCart();
}

function changeQuantity(id, amount) {
  const item = findInCart(id);
  item.quantity = item.quantity + amount;

  if (item.quantity <= 0) {
    removeFromCart(id);
  } else {
    updateCart();
  }
}

function removeFromCart(id) {
  // filter() keeps every item EXCEPT the one with this id
  cart = cart.filter(function (item) {
    return item.id !== id;
  });
  updateCart();
}

function clearCart() {
  cart = [];
  updateCart();
}

function checkout() {
  clearCart();
  cartMessage.textContent = "Thank you! Your demo order has been placed.";
}

for (const button of addButtons) {
  button.addEventListener("click", function () {
    addToCart(getBookFromCard(button.closest(".book-card")));
  });
}

checkoutBtn.addEventListener("click", checkout);
clearBtn.addEventListener("click", clearCart);


// ===== 8. CART: SHOW THE DATA ON THE PAGE =====
function updateCart() {
  let html = "";
  let total = 0;
  let count = 0;

  // Build one <li> for each item and add up the totals
  for (const item of cart) {
    html += `
      <li class="cart-item">
        <img src="${item.image}" alt="">
        <div>
          <h3>${item.title}</h3>
          <p class="price">${formatPrice(item.price)}</p>
          <div class="qty">
            <button data-action="decrease" data-id="${item.id}">-</button>
            <span>${item.quantity}</span>
            <button data-action="increase" data-id="${item.id}">+</button>
          </div>
        </div>
        <button class="close-btn" data-action="remove" data-id="${item.id}">&times;</button>
      </li>`;

    total = total + item.price * item.quantity;
    count = count + item.quantity;
  }

  if (cart.length === 0) {
    html = '<li class="cart-empty">Your cart is empty.</li>';
  }

  cartItems.innerHTML = html;
  cartTotal.textContent = formatPrice(total);
  cartCount.textContent = count;
  checkoutBtn.disabled = (cart.length === 0);
  clearBtn.style.display = (cart.length === 0) ? "none" : "";

  saveCart();
}

// The +, - and x buttons are created by JavaScript, so they do not exist when the
// page loads. Instead of adding a listener to each one, we listen on the whole
// list and check which button was clicked (this is called "event delegation").
cartItems.addEventListener("click", function (event) {
  const action = event.target.dataset.action;
  const id = event.target.dataset.id;

  if (action === "increase") {
    changeQuantity(id, 1);
  } else if (action === "decrease") {
    changeQuantity(id, -1);
  } else if (action === "remove") {
    removeFromCart(id);
  }
});


// ===== 9. SAVE AND LOAD THE CART (localStorage) =====
// localStorage keeps text in the browser. JSON.stringify turns the array into text,
// and JSON.parse turns the text back into an array.
function saveCart() {
  localStorage.setItem("pageturner-cart", JSON.stringify(cart));
}

function loadCart() {
  const saved = localStorage.getItem("pageturner-cart");
  if (saved) {
    cart = JSON.parse(saved);
  }
}


// ===== 10. KEYBOARD =====
// Press the Escape key to close any pop-up
document.addEventListener("keydown", function (event) {
  if (event.key === "Escape") {
    closeModal();
    closeCart();
  }
});


// ===== 11. START THE PAGE =====
loadCart();
updateCart();
